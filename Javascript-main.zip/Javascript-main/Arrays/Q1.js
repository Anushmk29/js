
// Add Element to End of Array
let arr = [1,2,3]
arr.push(4)
console.log(arr)  