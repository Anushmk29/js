// Remove Last Element from Array
let arr = [1,2,3,4]
arr.pop()
console.log(arr)  