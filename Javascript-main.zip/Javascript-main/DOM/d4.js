const newElement = document.createElement("p"); // Example: create a paragraph element
